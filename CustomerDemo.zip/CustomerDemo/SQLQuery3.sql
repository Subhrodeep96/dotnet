create table Subhrodeep.CustomerDetails
(
CustomerID int identity(1000,1) primary key,
CustomerName varchar(30),
DateofBirth datetime,
CustomerAddress varchar(50),
CustomerLocation varchar(30),
CustomerPh bigint 

)

insert into Subhrodeep.CustomerDetails values('Priyarupa',1998,'Santospur','Kolkata',7894561230);
insert into Subhrodeep.CustomerDetails values('Titash',1996,'Jadavpur','Kolkata',7894588230);

select * from Subhrodeep.CustomerDetails
-----------------------------------------------
 create proc Subhrodeep.usp_DisplayCustomerDetails
 AS
 BEGIN
 select * from Subhrodeep.CustomerDetails 
 END 

 exec Subhrodeep.usp_DisplayCustomerDetails
 -------------------------------------------------------

 create proc Subhrodeep.usp_DeleteCustomerDetails
 @eid int
 AS
 BEGIN
 delete from Subhrodeep.CustomerDetails where CustomerID=@eid
 END
 -------------------------------------------------------------
 