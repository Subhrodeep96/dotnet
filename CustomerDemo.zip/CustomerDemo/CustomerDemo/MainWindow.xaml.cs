﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace CustomerDemo
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        // display customer details

        private void btn_display_Click(object sender, RoutedEventArgs e)
        {
            Sep19CHNEntities contextobj = new CustomerDemo.Sep19CHNEntities();
          
               if (txt_CLOC.Text != string.Empty)
               {
            var query = from CustomerDetail emp in contextobj.CustomerDetails
                            //where emp.DeptId ==10 &&
                            //  where emp.EmpLocation= txt_emplocation.Text
                        select emp;

            dg_customer.ItemsSource = query.ToList();
            }
             else MessageBox.Show("please enter location");

        }
        // delete customer details by primary key
        private void btn_delete_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Sep19CHNEntities contextObj = new CustomerDemo.Sep19CHNEntities();
               CustomerDetail empDlt = new CustomerDemo.CustomerDetail();
                int customerID = Convert.ToInt32(txt_CustomerID.Text);
                empDlt = contextObj.CustomerDetails.FirstOrDefault(emp => emp.CustomerID == customerID);
                if (empDlt != null)
                {
                    contextObj.CustomerDetails.Remove(empDlt);
                    contextObj.SaveChanges();
                    MessageBox.Show("Customer Deleted Successfully");

                }
                else { throw new Exception("Can't Delete"); }

            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.ToString());
            }
            // display the customers whose date of birth year is between 1996 and 1998



        }


    }
    }

