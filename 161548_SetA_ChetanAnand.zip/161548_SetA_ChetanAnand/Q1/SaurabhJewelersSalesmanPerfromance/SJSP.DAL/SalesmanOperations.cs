﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using SJSP.Entity; //refrence to Entity class
using SJSP.Exceptions; //refrence to exceptions class


/// <summary>
/// Employee ID : 161548
/// Employee Name : Chetan Anand
/// Description : This is the DAL Layer class library for the salesman performance tracking application main use is to store the data. 
/// Modified On : 8/Oct/2018
/// </summary>
/// 

namespace SJSP.DAL
{
    public class SalesmanOperations
    {
        static List<Salesman> salesmanList = new List<Salesman>();

        //Method to add new salesman
        public static bool AddSalesman(Salesman salesman)
        {
            bool isAdded = false;

            try
            {
                //Adding salesman in the list
                salesmanList.Add(salesman);
                isAdded = true;
            }
            catch (SalesmanException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return isAdded;
        }
        
        //method to search salesman
        public static Salesman SearchSalesman(int salesmanCode)
        {
            Salesman salesman = null;

            try
            {
                //Searching salesman
                salesman = salesmanList.Find(s => s.SalesmanCode == salesmanCode);
            }
            catch (SalesmanException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return salesman;
        }

        //Method to Serialize Salesman Data
        public static bool SerializeSalesman()
        {
            bool isSerialized = false;

            try
            {
                //Creating object of stream
                FileStream fs = new FileStream("SalesDetails.txt", FileMode.Create, FileAccess.Write);
                //Creating BinaryFormatter object
                BinaryFormatter bin = new BinaryFormatter();
                //Serializing salesman data in stream
                bin.Serialize(fs, salesmanList);
                fs.Close();
                isSerialized = true;
            }
            catch (SalesmanException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return isSerialized;
        }

        //Method to deserialize Salesman details
        public static List<Salesman> DeserializeSalesman()
        {
            List<Salesman> salesmanDesList = null;

            try
            {
                //Creating object of stream
                FileStream fs = new FileStream("SalesDetails.txt", FileMode.Open, FileAccess.Read);
                //Creating BinaryFormatter object
                BinaryFormatter bin = new BinaryFormatter();
                //Deserializing salesman data from stream
                salesmanDesList = (List<Salesman>)bin.Deserialize(fs);
                fs.Close();
            }
            catch (SalesmanException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return salesmanDesList;
        }

    }
}
