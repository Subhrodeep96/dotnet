﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/// <summary>
/// Employee ID : 161548
/// Employee Name : Chetan Anand
/// Description : This is the entity class library for the salesman performance tracking application 
/// Modified On : 8/Oct/2018
/// </summary>
namespace SJSP.Entity
{
    [Serializable]
    public class Salesman
    {
        //property to store Salesman code
        public int SalesmanCode { get; set; }

        //property to store salesman name
        public string SalesmanName { get; set; }

        //property to store salesman region
        public string SalesmanRegion { get; set; }

        //property to store target sales of salesman
        public double SalesmanTarget { get; set; }

        //property to store Actual Tagerts of salesman
        public double SalesmanActualTarget { get; set; }
    }
}
