﻿using System;
using System.Collections.Generic;
using System.IO; //reference to the IO libray to access file operations
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/// <summary>
/// Employee ID : 151648
/// Employee Name : Chetan Anan
/// Description : Console Application developed to read data to file using StreamWriter and reading the data using StreamReader
/// Modified On : 8/Oct/2018
/// </summary>

namespace StreamReaderWriter
{
    class Program
    {
        static void Main(string[] args)
        {
            //creating file stream object 
            FileStream customerDetailsFileStream = new FileStream("CustomerDetails.txt", FileMode.Create, FileAccess.Write);
            
            //creating stream writer object
            StreamWriter customerDetailsStreamWriter = new StreamWriter(customerDetailsFileStream);
            
            //writing the given data to the file using stream writer
            customerDetailsStreamWriter.WriteLine("This are Customer details for the year 2015-2016. Most of our Customers are from east zone");

            //calling flush method to finilize the changes in file
            customerDetailsStreamWriter.Flush();

            //closing the file stream
            customerDetailsFileStream.Close();

            //file stream object to read the data from file
            customerDetailsFileStream = new FileStream("CustomerDetails.txt", FileMode.Open, FileAccess.Read);

            //stream reader to read the data in form of stream form the file
            StreamReader customerDetailsStreamReader = new StreamReader(customerDetailsFileStream);

            //writing the data
            Console.WriteLine(customerDetailsStreamReader.ReadToEnd());

            //closing the file stream
            customerDetailsFileStream.Close();

            Console.ReadKey();
        }
    }
}
