﻿using ProductApi.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace ProductApi.Controllers
{
    public class ProductsController : ApiController
    {
        Product[] products = new Product[]
        {
            new Product{ProductID=101,Name="Hot Wheels",Price=190.00F},
            new Product{ProductID=102,Name="Barbie",Price=88.99F}
        };

        [Route("Products")]
        public IEnumerable<Product> Get()
        {
            return products;
        }

        [Route("Products/{id:int}")]
        public IHttpActionResult GetProduct(int id)
        {
            var product = products.FirstOrDefault((p) => p.ProductID == id);

            if (products == null)
            {
                return NotFound();
            }

            return Ok(product);
        }


    }
}
