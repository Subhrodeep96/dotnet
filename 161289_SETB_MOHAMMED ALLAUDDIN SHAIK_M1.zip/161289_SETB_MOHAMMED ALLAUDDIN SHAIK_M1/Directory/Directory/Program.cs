﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Directory
{
    /// <summary>
    /// Employee ID : 161289
    /// Employee Name : Mohammed Allauddin Shaik
    /// Description : This is an Entity Class for Directory
    /// Date of Modification : 8th Oct 2018
    /// </summary>
    class Program
    {
        static void Main(string[] args)
        {
            //diclaration of sting
            string dirName;
            Console.Write("Enter Directory Name with Full Path :");
            //object is created
            dirName = Console.ReadLine();

            DirectoryInfo dir = new DirectoryInfo(dirName);
            //checking wheather directory is present or not
            if (dir.Exists)
            {
                
                DirectoryInfo[] subDir = dir.GetDirectories();
                //Displaying files in the directory
                
                for (int i = 0; i < subDir.Length; i++)
                {
                    Console.WriteLine(subDir[i].Name);
                }


                FileInfo[] files = dir.GetFiles();
                Console.WriteLine("\nNumber of files :" + files.Length);
                for (int i = 0; i < files.Length; i++)
                {
                    Console.WriteLine(files[i].Name);
                }


            }
            else
            {
                Console.WriteLine("Check the Directory Path");
            }
            Console.ReadKey();
        }
    }
}
