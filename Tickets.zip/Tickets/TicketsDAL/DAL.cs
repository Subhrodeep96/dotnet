﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Data.SqlClient;
using System.Data;
using TicketsException;
using TicketsEntity;
using System.Configuration;


namespace TicketsDAL
{
    public class DAL
    {
        static string patConnStr = ConfigurationManager.ConnectionStrings["conStr"].ToString();
        static SqlConnection patConnObj;
        SqlCommand patCommand;
        DataTable dtPat;
        SqlDataReader patReader = null;
        public DAL()
        {
            patConnObj = new SqlConnection();
            patConnObj.ConnectionString = patConnStr;
        }

        //method to get patient details in data table
        public DataTable LoadPatient()
        {

            try
            {
                dtPat = new DataTable();
                patCommand = new SqlCommand(" MatchDay.Results", patConnObj);
                patCommand.CommandType = CommandType.StoredProcedure;
                patConnObj.Open();
                patReader = patCommand.ExecuteReader();
                dtPat.Load(patReader);

            }
            catch (SqlException)
            {
                throw;

            }
            catch (System.Exception)
            {

                throw;
            }
            finally
            {
                patReader.Close();
                if (patConnObj.State == ConnectionState.Open) patConnObj.Close();
            }
            return dtPat;
        }
    }
}
