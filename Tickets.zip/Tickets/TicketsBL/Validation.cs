﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using TicketsDAL;
using TicketsException;
using TicketsEntity;


namespace TicketsBL
{
    public class Validation
    {
        DAL operations;
        public DataTable LoadDeparment_BLL()
        {
            DataTable dtPat;
            try
            {
                operations = new DAL();
                dtPat = operations.LoadPatient();
            }
            catch (SqlException se)
            {

                throw se;
            }
            catch (System.Exception ex)
            {

                throw ex;
            }
            return dtPat;
        }
    }
}
