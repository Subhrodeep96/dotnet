﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TicketsEntity
{
    public class Entity
    {
        public int mFixno { get; set; }
        public DateTime mFixdates { get; set; }
        public string mfixtures { get; set; }
        public string stadium { get; set; }
        public string location { get; set; }
    }
}
