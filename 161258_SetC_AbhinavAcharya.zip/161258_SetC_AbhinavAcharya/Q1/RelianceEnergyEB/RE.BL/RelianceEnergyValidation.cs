﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Text;
using System.Threading.Tasks;
using RE.Entity;        //reference for Reliance Energy Entity
using RE.Exception;     //reference for Reliance Energy Exception
using RE.DAL;           //reference for Reliance Energy Data Access

namespace RE.BL
{
    /// <summary>
    /// Employee ID : 161258
    /// Employee Name : Abhinav Acharya
    /// Description : This class will have business logic for Reliance Energy
    /// Date of Modification : 8th Oct 2018
    /// </summary>
    public class RelianceEnergyValidation
    {
        //Method to validate Reliance Energy Bill details
        public static bool ValidateBill(RelianceEnergy re)
        {
            bool isValidated = true;

            StringBuilder message = new StringBuilder();

            try
            {
                //Checking Bill No. should not be null
                if (re.BillNo == 0)
                {
                    message.Append("Bill Number cannot be left empty\n");
                    isValidated = false;
                }

                //Checking Customer ID should not be empty
                if (re.CustomerId == 0)
                {
                    message.Append("Customer Id cannot be left empty\n");
                    isValidated = false;
                }

                //Checking Phone Number
                if (!Regex.IsMatch(re.Phone, "[7-9][0-9]{9}"))
                {
                    message.Append("Phone number should start with 7 or 8 or 9 and it should have exactly 10 digits\n");
                    isValidated = false;
                }

                
            }

            catch (RelianceEnergyException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return isValidated;

        }

        //Method to add new bill
        public static bool AddBill(RelianceEnergy re)
        {
            bool isAdded = false;
            try
            {
                //validating Reliance Energy Bill
                if(ValidateBill(re))
                {
                    //Adding the bill by calling DAL Add method
                    isAdded = RelianceEnergyOperations.AddBill(re);
                }
                else
                    throw new RelianceEnergyException("Please provide valid Reliance Energy Electricity details");
            }
            catch (RelianceEnergyException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return isAdded;
        }

        //Method to search new bill
        public static RelianceEnergy SearchBill(int custID)
        {
            RelianceEnergy re = null;

            try
            {
                   //Searching bill by calling DAL search method
                   re = RelianceEnergyOperations.SearchBill(custID);
            }
            catch (RelianceEnergyException ex)
            {
             throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return re;
    }

        //Method to display all bills
        public static List<RelianceEnergy> DisplayBill()
        {
            List<RelianceEnergy> relianceData = null;

            try
            {
                //displaying bills by calling DAL display method
                relianceData = RelianceEnergyOperations.DisplayBill();
            }
            catch(RelianceEnergyException ex)
            {
                throw ex;
            }
            catch(SystemException ex)
            {
                throw ex;
            }

            return relianceData;
        }
    }
}
