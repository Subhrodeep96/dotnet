﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RE.Entity
{
    /// <summary>
    /// Employee ID : 161258
    /// Employee Name : Abhinav Acharya
    /// Description : This is an Entity Class for Reliance Energy
    /// Date of Modification : 8th Oct 2018
    /// </summary>
    [Serializable]
    public class RelianceEnergy
    {
        private int billNo;
        private int customerId;
        private string customerName;
        private string phone;
        private int units;
        private int amount;
        private int rate;
        private int surge;
        private int gross;

        //property to get and set Bill Number
        public int BillNo
        {
            get { return billNo; }
            set { billNo = value; }
        }

        //property to get and set Customer Id
        public int CustomerId
        {
            get { return customerId; }
            set { customerId = value; }
        }

        //property to get and set Customer Name
        public string CustomerName
        {
            get { return customerName; }
            set { customerName = value; }
        }

        //property to get and set Phone
        public string Phone
        {
            get { return phone; }
            set { phone = value; }
        }

        //property to get and set Units
        public int Units
        {
            get { return units; }
            set { units = value; }
        }

        //property to get and set surge
        public int Surge
        {
            get { return (5*amount)/100; }
            set { surge = value; }
        }

        //property to get and set gross
        public int Gross
        {
            get { return amount+surge; }
            set { gross = value; }
        }

        //property to get and set rate
        public int Rate
        {
            get { return rate; }
            set { rate = value; }
        }

        //property to get and set Bill Amount
        public int Amount
        {
            get { return units*rate; }
            set { amount = value; }
        }

        //Default Constructor
        public RelianceEnergy()
        {
            this.billNo = 0;
            this.customerId = 0;
            this.CustomerName = string.Empty;
            this.phone = string.Empty;
            this.units = 0;
            this.amount = 0;
        }
    }
}