﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RE.Exception
{
    /// <summary>
    /// Employee ID : 161258
    /// Employee Name : Abhinav Acharya
    /// Description : This is an user defined exception class for Reliance Energy
    /// Date of Modification : 8th Oct 2018
    /// </summary>
    public class RelianceEnergyException : ApplicationException
    {
        //Default Constructor
        public RelianceEnergyException() : base()
        {
        }

        //parameterized constructor with one parameter
        public RelianceEnergyException(string message)
            : base(message)
        {
        }
    }
}
