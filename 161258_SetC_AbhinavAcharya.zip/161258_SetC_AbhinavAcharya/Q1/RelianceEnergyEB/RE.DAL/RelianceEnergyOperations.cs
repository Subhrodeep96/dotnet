﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using RE.Entity;        //reference for Reliance Energy Entity
using RE.Exception;     //reference for Reliance Energy Exception

namespace RE.DAL
{
    /// <summary>
    /// Employee ID : 161258
    /// Employee Name : Abhinav Acharya
    /// Description : This class will provide CRUD operations for Reliance Energy
    /// Date of Modification : 8th Oct 2018
    /// </summary>
    public class RelianceEnergyOperations
    {
        //creating list to store reliance details
        public static List<RelianceEnergy> relianceData = new List<RelianceEnergy>();

        //Method to add details for reliance energy electricity bill
        public static bool AddBill(RelianceEnergy RE)
        {
            bool isAdded = false;
            try
            {
                relianceData.Add(RE);
                isAdded = true;
            }
            catch(RelianceEnergyException ex)
            {
                throw ex;
            }
            catch(SystemException ex)
            {
                throw ex;
            }

            return isAdded;
        }

        public static RelianceEnergy SearchBill(int custID)
        {
            RelianceEnergy re = null;
            try
            {
                //searching customerID
                re = relianceData.Find(r => r.CustomerId == custID);
            }
            catch (RelianceEnergyException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return re;
        }

        //Method to display all employee
        public static List<RelianceEnergy> DisplayBill()
        {
            return relianceData;
        }
     }
 }

