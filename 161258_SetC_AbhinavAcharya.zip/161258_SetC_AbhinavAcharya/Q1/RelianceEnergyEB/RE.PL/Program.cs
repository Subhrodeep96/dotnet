﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RE.BL;                //reference for Reliance Energy Validation
using RE.DAL;               //reference for Reliance Energy Data Access
using RE.Entity;            //reference for Reliance Energy Entity
using RE.Exception;         //reference for Reliance Energy Exception

namespace RE.PL
{
    class Program
    {
        private static object ex;

        //Method to add new bill
        public static void Addbill()
        {
            try
            {
                RelianceEnergy re = new RelianceEnergy();
                Console.Write("Enter Bill No : ");
                re.BillNo = Convert.ToInt32(Console.ReadLine());

                Console.Write("Enter Customer ID : ");
                re.CustomerId = Convert.ToInt32(Console.ReadLine());

                Console.Write("Enter the Customer Name : ");
                re.CustomerName = Console.ReadLine();

                Console.Write("Enter Phone Number");
                re.Phone = Console.ReadLine();

                Console.Write("Enter the Units Consumed");
                re.Units = Convert.ToInt32(Console.ReadLine());

                Console.Write("Enter the Rate");
                re.Units = Convert.ToInt32(Console.ReadLine());

                bool isAdded = RelianceEnergyValidation.AddBill(re);

                if (isAdded)
                {
                    Console.WriteLine("The Electricity Bill Details added successfully");
                }
                else
                    throw new RelianceEnergyException("Electricity Bill not added");
            }
            catch (RelianceEnergyException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }

        }
            public static void SeachBill()
        {
            try
            {
                int custID;

                Console.Write("Enter the Customer ID to search : ");
                custID = Convert.ToInt32(Console.ReadLine());

                RelianceEnergy re = RelianceEnergyValidation.SearchBill(custID);

                if (re != null)
                {
                    Console.WriteLine("Bill No : " + re.BillNo);
                    Console.WriteLine("Customer ID : " + re.CustomerId);
                    Console.WriteLine("Customer Name : " + re.CustomerName);
                    Console.WriteLine("Phone : " + re.Phone);
                    Console.WriteLine("Units consumed : " + re.Units);
                    Console.WriteLine("Rate : " + re.Rate);
                    Console.WriteLine("Gross : " + re.Gross);
                    Console.WriteLine("Amount : " + re.Amount);
                }
                else
                    throw new RelianceEnergyException("Customer ID not found ");
            }
            catch (RelianceEnergyException ex)
            {

                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public static void PrintMenu()
        {
            Console.WriteLine("----------------------------");
            Console.WriteLine("1. Add Bill details");
            Console.WriteLine("2. Search CustomerID");
            Console.WriteLine("3. Exit");
            Console.WriteLine("----------------------------");
        }

    
        static void Main(string[] args)
        {
        try
        {
            int choice;

            do
            {
                PrintMenu();
                Console.Write("Enter your choice : ");
                choice = Convert.ToInt32(Console.ReadLine());

                switch (choice)
                {
                    case 1: Addbill();
                            break;
                        case 2: SeachBill();
                            break;
                        case 3: Environment.Exit(0);
                            break;
                        default:
                            Console.Write("Invalid Choice");
                            break;
                    }
                } while (choice != 8);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }

            Console.ReadKey();

        }
    }
}
