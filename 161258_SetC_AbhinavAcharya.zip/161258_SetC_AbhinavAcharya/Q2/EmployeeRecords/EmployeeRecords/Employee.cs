﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeRecords
{
    /// <summary>
    /// Author:Abhinav Acharya
    /// Purpose:Class Of Employee
    /// Date:08/10/2018
    /// </summary>
    class Employee
    {
        //Declare private variable for employee class
        private int empId;
        private string empName;
        private string gender;
        private DateTime dateOfBirth;

        //Declare EmpId property
        public int EmpId
        {
            get { return empId; }
            set { empId = value; }
        }
        //Declare EmpName property
        public string EmpName
        {
            get { return empName; }
            set { empName = value; }
        }
        //Declare Gender property
        public string Gender
        {
            get { return gender; }
            set { gender = value; }
        }
        //Declare DateOfBirth property
        public DateTime DateOfBirth
        {
            get { return dateOfBirth; }
            set { dateOfBirth = value; }
        }

        //Default Constructor
        public Employee()
        {
            EmpId = 0;
            EmpName = string.Empty;
            Gender = string.Empty;
            DateOfBirth = DateTime.Now.Date;
        }

        //Parameterized Constructor with four parameter
        public Employee(int empId, string empName, string gender, DateTime dateOfBirth)
        {
            EmpId = empId;
            EmpName = empName;
            Gender = gender;
            DateOfBirth = dateOfBirth;
        }

        //Display Method to Display all data
        public void DisplayDetails()
        {
            Console.WriteLine("DETAILS OF THE EMPLOYEE");
            Console.WriteLine("=====================================");
            Console.WriteLine($"Employee ID:{EmpId}\nName:{EmpName}\nGender:{Gender}\nDate Of Birth:{DateOfBirth}");
            Console.WriteLine("=====================================");
        }
    }
}