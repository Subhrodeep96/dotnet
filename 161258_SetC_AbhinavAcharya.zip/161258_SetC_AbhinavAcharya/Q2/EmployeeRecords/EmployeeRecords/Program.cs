﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeRecords
{
    /// <summary>
    /// Author:Abhinav Acharya
    /// Purpose:Main Class to run the program
    /// Date:08/10/2018
    /// </summary>
    class Program
    {
        static void Main(string[] args)
        {
            //passing parameter using parameterized constructor
            Employee emp = new Employee(101, "Vineetha", "Female", new DateTime(1980 , 10 , 9));

            //calling a display method using DisplayDetails() method
            emp.DisplayDetails();

            Console.ReadLine();
        }
    }
}
