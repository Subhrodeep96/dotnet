﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMSException
{
    /// <summary>
    /// Employee ID : 161289
    /// Employee Name : Mohammed Allauddin Shaik
    /// Description : This is an Entity Class for Student
    /// Date of Modification : 8th Oct 2018
    /// </summary>
    public class StudentException : ApplicationException
    {
        //Default Constructor , that inherits the base constructor
        public StudentException() : base() { }

        // Parameterized constructor for passing the Error/Exception Message
        public StudentException(string errormsg) :
            base(errormsg)
        { }

    }
}
