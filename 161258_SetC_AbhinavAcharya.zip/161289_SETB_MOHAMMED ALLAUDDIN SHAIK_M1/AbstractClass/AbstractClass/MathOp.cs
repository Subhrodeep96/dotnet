﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbstractClass
{
    /// <summary>
    /// Employee ID : 161289
    /// Employee Name : Mohammed Allauddin Shaik
    /// Description : This is an Entity Class for Abstract
    /// Date of Modification : 8th Oct 2018
    /// </summary>
    class MathOp
    {
    }
}
