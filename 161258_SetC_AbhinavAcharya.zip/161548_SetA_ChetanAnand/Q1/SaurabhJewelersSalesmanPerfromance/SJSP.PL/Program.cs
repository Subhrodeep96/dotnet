﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SJSP.Entity; //refrence to entity
using SJSP.Exceptions; //refrence to exceptions
using SJSP.BL; //refrence to Bl
/// <summary>
/// Employee ID : 161548
/// Employee Name : Chetan Anand
/// Description : This is the PL i.e the console application for SJSP . 
/// Modified On : 8/Oct/2018
/// </summary>
/// 
namespace SJSP.PL
{
    class Program
    {

        //Method to add new salesman
        public static void AddSalesman()
        {
            try
            {
                //creating object to access salesman properties
                Salesman salesman = new Salesman();

                //input salesman code
                Console.Write("Enter Salesman Code : ");
                salesman.SalesmanCode = Convert.ToInt32(Console.ReadLine());

                //input salesman name
                Console.Write("Enter Salesman Name : ");
                salesman.SalesmanName = Console.ReadLine();

                //input salesman region
                Console.Write("Enter Salesman Region : ");
                salesman.SalesmanRegion = Console.ReadLine();

                //input salesman target
                Console.Write("Enter Salesman Target : ");
                salesman.SalesmanTarget = Convert.ToDouble(Console.ReadLine());


                //input salesmamn actual target
                Console.Write("Enter Salesman Actual Target(Target Met) : ");
                salesman.SalesmanActualTarget = Convert.ToDouble(Console.ReadLine());

                //validate salesman
                bool isAdded = SalesmanValidation.AddSalesman(salesman);

                //check if validated
                if (isAdded)
                {
                    Console.WriteLine("Salesman details added successfully");
                }
                //if not throw an exception
                else
                    throw new SalesmanException("Salesman details not added");
            }
            catch (SalesmanException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        //Method to search salesman
        public static void SearchSalesman()
        {
            try
            {
                int salesmanCode;
                //INPUT SALESMAN CODE TO BE SEARCHED
                Console.Write("Enter Salesman Code for Search : ");
                salesmanCode = Convert.ToInt32(Console.ReadLine());

                //search salesman and store returned value in salesman object
                Salesman salesman = SalesmanValidation.SearchSalesman(salesmanCode);

                //if  found print details of salesman
                if (salesman != null)
                {
                    Console.WriteLine("Salesman Code : " + salesman.SalesmanCode);
                    Console.WriteLine("Salesman Name : " + salesman.SalesmanName);
                    Console.WriteLine("Salesman Region : " + salesman.SalesmanRegion);
                    Console.WriteLine("Salesman Target : " + salesman.SalesmanTarget);
                    Console.WriteLine("Salesman Actual Target : " + salesman.SalesmanActualTarget);
                    
                }
                //if not found throw exception that salesman with salesmanCode not found
                else
                    throw new SalesmanException("Salesman " + salesmanCode + " not found");
            }
            catch (SalesmanException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        //method to serialize salesman
        public static void SerializeSalesman()
        {
            try
            {
                //calling the serialization method
                bool isSerialized = SalesmanValidation.SerializeSalesman();

                //checking if data is serialized
                if (isSerialized)
                    Console.WriteLine("Salesman Data is Serialized");
                //if not then throw an exception
                else
                    throw new SalesmanException("Salesman Data is not Serialized");
            }
            catch (SalesmanException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        //deserializing data and displaying it alongwith deserialization
        public static void DeserializeSalesman()
        {
            try
            {
                //calling deserializing algorithm and storing the return list in salesamnList
                List<Salesman> salesmanList = SalesmanValidation.DeserializeSalesman();
                //checking if list is not empty and printing the data
                if (salesmanList != null || salesmanList.Count > 0)
                {
                    
                    Console.WriteLine("|Salesman Code|   |Salesman Name|   |Salesman Region|   |Salesman Target|   |Salesman Actual Target|");
                    
                    foreach (Salesman salesman in salesmanList)
                    {
                        Console.WriteLine(salesman.SalesmanCode + "\t" + salesman.SalesmanName + "\t" + salesman.SalesmanRegion + "\t" + salesman.SalesmanTarget + "\t" + salesman.SalesmanActualTarget);
                    }
                    
                }
                //if list is empty throw exception
                else
                    throw new SalesmanException("Salesman Details not deserialized");
            }
            catch (SalesmanException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        //menu for the application
        public static void PrintMenu()
        {
            Console.WriteLine("----------------------------");
            Console.WriteLine("1. Add Salesman");
            Console.WriteLine("2. Search Salesman");
            Console.WriteLine("3. Serialize Salesman");
            Console.WriteLine("4. Deseialize and Display Salesman");
            Console.WriteLine("5. Exit");
            Console.WriteLine("----------------------------");
        }

        
        static void Main(string[] args)
        {

            try
            {
                //variable to store user's choice
                int choice;

                do
                {
                    PrintMenu();//printing menu using PrintMenu()

                    //reading user's choice
                    Console.Write("Enter your choice : ");
                    choice = Convert.ToInt32(Console.ReadLine());

                    //switch case on users choice to ececute desired operation
                    switch (choice)
                    {
                        case 1:
                            AddSalesman();
                            break;
                        case 2:
                            SearchSalesman();
                            break;
                        case 3:
                            SerializeSalesman();
                            break;
                        case 4:
                            DeserializeSalesman();
                            break;
                        case 5:
                            Environment.Exit(0);
                            break;
                        default:
                            Console.Write("Invalid Choice");
                            break;
                    }
                } while (choice != 5);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }

            
        }



    }
}

