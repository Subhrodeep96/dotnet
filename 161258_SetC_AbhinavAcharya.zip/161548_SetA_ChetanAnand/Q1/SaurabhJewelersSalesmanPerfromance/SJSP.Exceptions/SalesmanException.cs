﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/// <summary>
/// Employee ID : 161548
/// Employee Name : Chetan Anand
/// Description : This is the Excepetion class library for the salesman performance tracking application 
/// Modified On : 8/Oct/2018
/// </summary>

namespace SJSP.Exceptions
{
    public class SalesmanException : ApplicationException
    {
        //default constructor
        public SalesmanException()
            : base() { }

        //parameterized constructor to pass message
        public SalesmanException(string message)
            : base(message) { }
    }
}
