﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SJSP.Entity; //refrence to entity libray
using SJSP.Exceptions; //refremce to exceptions library
using SJSP.DAL; //refrence to DAL library

/// <summary>
/// Employee ID : 161548
/// Employee Name : Chetan Anand
/// Description : This is the BL Layer class library for the salesman performance tracking application main use is to validate the enetered data. 
/// Modified On : 8/Oct/2018
/// </summary>
/// 

namespace SJSP.BL
{
    public class SalesmanValidation
    {
        //Method to validate salesman details
        public static bool ValidateSalesman(Salesman salesman)
        {
            bool isValidated = true;

            StringBuilder message = new StringBuilder();

            try
            {
                //Checking salesman code that it should be 4 digits
                if (salesman.SalesmanCode < 1000 || salesman.SalesmanCode > 9999)
                {
                    message.Append("Salesman Code Must Be 4 Digit Long\n");
                    isValidated = false;
                }

                //Checking salesman code not to be empty 
                if (salesman.SalesmanCode.ToString() == string.Empty)
                {
                    message.Append("Salesman code can't be empty\n");
                    isValidated = false;
                }
                
                //Checking salesman region
                if (salesman.SalesmanRegion.ToLower() != "north" && salesman.SalesmanRegion.ToLower() != "west" && salesman.SalesmanRegion.ToLower() != "east" && salesman.SalesmanRegion.ToLower() != "south")
                {
                    message.Append("Salesman region should be either of North,South,East or West\n");
                    isValidated = false;
                }

                if (isValidated == false)
                    throw new SalesmanException(message.ToString());
            }
            catch (SalesmanException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return isValidated;
        }
        
        //Method to add new salesman
        public static bool AddSalesman(Salesman salesman)
        {
            bool isAdded = false;

            try
            {
                //Validating employee details
                if (ValidateSalesman(salesman))
                {
                    //Adding the employee by calling DAL Add method
                    isAdded = SalesmanOperations.AddSalesman(salesman);
                }
                else
                    throw new SalesmanException("Please provide valid salesman details");
            }
            catch (SalesmanException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return isAdded;
        }

        //Method to search salesman
        public static Salesman SearchSalesman(int salesmanCode)
        {
            Salesman salesman = null;

            try
            {
                //Searching salesman by calling DAL search method
                salesman = SalesmanOperations.SearchSalesman(salesmanCode);
            }
            catch (SalesmanException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return salesman;
        }

        //Method to serialize salesman details
        public static bool SerializeSalesman()
        {
            bool isSerialized = false;

            try
            {
                //Serializing by calling DAL serialize method
                isSerialized = SalesmanOperations.SerializeSalesman();
            }
            catch (SalesmanException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return isSerialized;
        }

        //Method to Deserialize Salesman
        public static List<Salesman> DeserializeSalesman()
        {
            List<Salesman> salesmanList = null;

            try
            {
                //deserializing salesman by calling DAL deserialize method
                salesmanList = SalesmanOperations.DeserializeSalesman();
            }
            catch (SalesmanException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return salesmanList;
        }


    }
}
