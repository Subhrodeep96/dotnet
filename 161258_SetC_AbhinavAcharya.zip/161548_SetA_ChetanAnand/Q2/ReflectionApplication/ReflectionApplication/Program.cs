﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Reflection;
/// <summary>
/// Employee ID : 161548
/// Employee Name : Chetan Anand
/// Description : this is console application to illustrate the reflections.
/// </summary>
/// 
namespace ReflectionApplication
{
    class Program
    {
        static void Main(string[] args)
        {
            Assembly myAssembly = Assembly.LoadFrom("ReflectionLibrary.dll");
            Type type = myAssembly.GetType("ReflectionLibrary.EmployeeProperties");

            PropertyInfo[] props = type.GetProperties();
            

            foreach (PropertyInfo p in props)
            {
                Console.WriteLine("Property Name : " + p.Name);
                Console.WriteLine("Can Read : " + p.CanRead);
                Console.WriteLine("Can Write : " + p.CanWrite);
                Console.WriteLine("Property Type : " + p.PropertyType);
                Console.WriteLine();
            }

            type = myAssembly.GetType("ReflectionLibrary.EmployeeField");
            FieldInfo[] fields = type.GetFields();

            foreach (FieldInfo f in fields)
            {
                Console.WriteLine("Fields Name : " + f.Name);
                Console.WriteLine("Fields is Public" + f.IsPublic);
                Console.WriteLine();
            }

            type = myAssembly.GetType("ReflectionLibrary.Constructors");
            ConstructorInfo[] constructors = type.GetConstructors();

            foreach (ConstructorInfo c in constructors)
            {
                Console.WriteLine("Property Name : " + c.Name);
                Console.WriteLine();
            }
        }
    }
}
