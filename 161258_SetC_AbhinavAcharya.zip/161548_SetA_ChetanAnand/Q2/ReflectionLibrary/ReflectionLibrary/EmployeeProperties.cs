﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/// <summary>
/// Employee ID : 161548
/// Employee Name : Chetan Anand
/// Description : this is class  library containing properties to illustrate the reflections.
/// Modified On : 8/Oct/2018
/// </summary>
namespace ReflectionLibrary
{
    class EmployeeProperties
    {
        //id property
        
        public int EmpID { get ; set ; }

        //name property
        
        public string EmpName { get; set; }

        //salary  property
        public double EmpSalary { get; set; }
    }
}
