﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/// <summary>
/// Employee ID : 161548
/// Employee Name : Chetan Anand
/// Description : this is class  library containing constructors to illustrate the reflections.
/// Modified On : 8/Oct/2018
/// </summary>
namespace ReflectionLibrary
{
    class Constructors
    {
        //default constructor
        public Constructors() { }

        //paramaterized constructor
        public Constructors(int id, string name)
        { }
    }
}
