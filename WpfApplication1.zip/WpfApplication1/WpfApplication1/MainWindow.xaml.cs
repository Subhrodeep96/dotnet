﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

namespace WpfApplication1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }


        public DataSet Disconnected()
        {
            DataSet dsEmployee = new DataSet();
            SqlConnection conObj = new SqlConnection();
           
            conObj.ConnectionString = ConfigurationManager.ConnectionStrings["conStr"].ToString();
          
            SqlDataAdapter daEmp = new SqlDataAdapter("select * from ", conObj); // enter sql command
            //Fill data into the DataSet
            daEmp.Fill(dsEmployee, "Emp");
            return dsEmployee;
        }
        public static DataTable LoadDataGrid()
        {
            SqlDataReader rdrEmp = null;
            SqlConnection connObj = new SqlConnection();
            DataTable dtEmp = new DataTable();
            // Initialize the Connection object and set the ConnectionString Property
            try
            {

                connObj.ConnectionString = @"Data Source=ndamssql\sqlilearn;Initial Catalog=Sep19CHN;User ID=sqluser;Password=sqluser";

              
                // put necessary sql commadn
                SqlCommand cmdObj = new SqlCommand("select * from [Geetha].[Employee]", connObj);

                // Execute the Command
                connObj.Open();
                rdrEmp = cmdObj.ExecuteReader();
                if (rdrEmp.HasRows)
                {

                    dtEmp.Load(rdrEmp);
                    // binding UI with data
                }

            }
            catch (SqlException se)
            {
                MessageBox.Show("Exception Occurred" + se.Message, "Player Form");
            }

            finally
            {
                rdrEmp.Close();
                if (connObj.State == ConnectionState.Open)
                    connObj.Close();
            }
            return dtEmp;
        }
        private void radioButton_Checked(object sender, RoutedEventArgs e)
        {
           
        }

        private void btn_search_Click(object sender, RoutedEventArgs e)
        {
            SqlConnection conObj = new SqlConnection(@"Data Source=ndamssql\sqlilearn;Initial Catalog=Sep19CHN;User ID=sqluser;Password=sqluser");
            SqlCommand searchCmd = new SqlCommand("IPL2k18.", conObj); // see this line dont know what to do, put sql command the search players one
            searchCmd.CommandType = CommandType.StoredProcedure;
            searchCmd.Parameters.AddWithValue("@eId", txt_search.Text);
            SqlDataReader rdr = null;
            conObj.Open();
            rdr = searchCmd.ExecuteReader();
            DataTable dtEmp = new DataTable();

            if (rdr.HasRows)
            {
                dtEmp.Load(rdr);
                
                txt_search.Text = dtEmp.Rows[0][1].ToString();
             
            }
            else MessageBox.Show("No records found");


            rdr.Close();
            conObj.Close();
        }

        private void rdb_player_Checked(object sender, RoutedEventArgs e)
        {
            
        }

        private void dataGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }
    }
}
